import tempfile
from pathlib import Path
from openpyxl import load_workbook
from core import account, parse_count, extract_profile, export_results

assert account('https://www.tiktok.com/@mattkahla') == 'mattkahla'
assert account('https://tiktok.com/@no_ou7/video/123') == 'no_ou7'
assert account('https://fake.example/@someone') is None
assert account('Matt Kahla, Jr.', True) is None
assert parse_count('12.3K') == (12300, '页面缩写估算')
assert parse_count('50,843') == (50843, '页面整数')

class Page:
    def evaluate(self, script):
        return [{'userInfo': {'user': {'uniqueId':'testuser', 'nickname':'Test'}, 'stats': {'followerCount':12345}}}]

assert extract_profile(Page(), 'testuser') == ('Test', 12345, '页面整数')
with tempfile.TemporaryDirectory() as folder:
    path = Path(folder) / 'results.xlsx'
    export_results([{'账号ID':'testuser', '达人名称':'=1+1', '粉丝数':None, '主页链接':'https://www.tiktok.com/@testuser', '查询时间UTC':'', '查询状态':'待查询', '粉丝数精度':'', '来源':['Sheet1!第3行']}], path)
    wb = load_workbook(path)
    assert wb.active['B2'].data_type == 's'
    assert wb.active['C2'].value is None
print('Core tests passed')
