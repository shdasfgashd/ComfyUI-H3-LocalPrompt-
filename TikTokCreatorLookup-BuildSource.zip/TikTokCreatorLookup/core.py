import re
from urllib.parse import urlsplit
from datetime import datetime, timezone
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill

def account(value, bare=False):
    if not isinstance(value, str):
        return None
    value = value.strip()
    if '://' in value:
        u = urlsplit(value)
        if (u.hostname or '').lower() not in ('tiktok.com', 'www.tiktok.com', 'm.tiktok.com'):
            return None
        m = re.match(r'/@([A-Za-z0-9_.]+)(?:/|$)', u.path)
        return m.group(1).lower() if m else None
    if value.startswith('@') or bare:
        value = value.lstrip('@')
        if re.fullmatch(r'[A-Za-z0-9_.]{1,24}', value):
            return value.lower()
    return None

def import_accounts(path):
    result = {}
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        for sheet in wb:
            handle_cols = set()
            for n, row in enumerate(sheet.values, 1):
                for col, value in enumerate(row):
                    if isinstance(value, str) and value.strip().lower() in ('handle', 'username', '账号', '账号id', 'tiktok账号', '达人账号'):
                        handle_cols.add(col)
                        continue
                    name = account(value, col in handle_cols)
                    if name:
                        item = result.setdefault(name, {'账号ID': name, '达人名称': '', '粉丝数': None,
                            '主页链接': 'https://www.tiktok.com/@' + name, '查询时间UTC': '',
                            '查询状态': '待查询', '粉丝数精度': '', '来源': []})
                        source = f'{sheet.title}!第{n}行'
                        if source not in item['来源']:
                            item['来源'].append(source)
    finally:
        wb.close()
    return list(result.values())

def parse_count(value):
    text = str(value).strip().replace(',', '').replace(' ', '')
    m = re.fullmatch(r'(\d+(?:\.\d+)?)([KMB万亿]?)', text, re.I)
    if not m:
        raise ValueError('无法识别粉丝数字: ' + text)
    multiplier = {'': 1, 'K': 1000, 'M': 1000000, 'B': 1000000000, '万': 10000, '亿': 100000000}[m[2].upper()]
    return int(float(m[1]) * multiplier), ('页面缩写估算' if m[2] else '页面整数')

def extract_profile(page, handle):
    # Only accept a structured user record whose username matches the requested account.
    nodes = page.evaluate('''() => {
      const output=[];
      for(const id of ['__UNIVERSAL_DATA_FOR_REHYDRATION__','SIGI_STATE']) {
        const e=document.getElementById(id); if(!e) continue;
        try { output.push(JSON.parse(e.textContent)); } catch(_) {}
      }
      return output;
    }''')
    def walk(node):
        if isinstance(node, dict):
            user, stats = node.get('user'), node.get('stats') or node.get('statsV2')
            if isinstance(user, dict) and isinstance(stats, dict):
                if str(user.get('uniqueId', '')).lower() == handle.lower():
                    count = stats.get('followerCount')
                    if count is not None and re.fullmatch(r'\d+', str(count)):
                        return user.get('nickname', ''), int(count), '页面整数'
            for value in node.values():
                found = walk(value)
                if found:
                    return found
        elif isinstance(node, list):
            for value in node:
                found = walk(value)
                if found:
                    return found
        return None
    found = walk(nodes)
    if found:
        return found
    shown_handle = page.locator('[data-e2e="user-title"]').first
    if shown_handle.count() and shown_handle.inner_text().strip().lstrip('@').lower() == handle.lower():
        followers = page.locator('[data-e2e="followers-count"]').first
        nickname = page.locator('[data-e2e="user-subtitle"]').first
        if followers.count():
            count, precision = parse_count(followers.inner_text())
            return nickname.inner_text().strip() if nickname.count() else '', count, precision
    return None

def export_results(items, destination):
    wb = Workbook()
    ws = wb.active
    ws.title = '达人查询结果'
    keys = ['账号ID', '达人名称', '粉丝数', '主页链接', '查询时间UTC', '查询状态', '粉丝数精度', '来源']
    ws.append(keys)
    for item in items:
        ws.append(['; '.join(item[k]) if isinstance(item[k], list) else item[k] for k in keys])
        for cell in ws[ws.max_row]:
            if isinstance(cell.value, str):
                cell.data_type = 's'
    for cell in ws[1]:
        cell.font = Font(bold=True, color='FFFFFF')
        cell.fill = PatternFill('solid', fgColor='24476B')
    for col, width in zip('ABCDEFGH', [26, 32, 18, 55, 28, 42, 22, 65]):
        ws.column_dimensions[col].width = width
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions
    wb.save(destination)

def timestamp():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')
