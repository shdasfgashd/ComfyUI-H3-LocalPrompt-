@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3 -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onedir --windowed --collect-all playwright --name TikTokCreatorLookup app.py
if errorlevel 1 goto failed
echo.
echo 打包完成：dist\TikTokCreatorLookup\TikTokCreatorLookup.exe
echo 请保留并分发整个 TikTokCreatorLookup 文件夹。
pause
exit /b 0
:failed
echo 打包失败。请安装 Windows Python 3.11 或 3.12，并检查网络连接。
pause
exit /b 1
