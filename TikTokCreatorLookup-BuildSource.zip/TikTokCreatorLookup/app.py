import os
import sys
import queue
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from core import import_accounts, extract_profile, export_results, timestamp

class App:
    def __init__(self, root):
        self.root = root
        root.title('TikTok 达人公开主页查询')
        root.geometry('1060x650')
        self.items = []
        self.events = queue.Queue()
        self.running = False
        self.stop = threading.Event()
        self.resume = threading.Event()
        self.folder = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'TikTokCreatorLookup'
        self.folder.mkdir(parents=True, exist_ok=True)
        bar = ttk.Frame(root, padding=12)
        bar.pack(fill='x')
        self.import_button = ttk.Button(bar, text='1. 导入 XLSX', command=self.load)
        self.import_button.pack(side='left', padx=4)
        self.start_button = ttk.Button(bar, text='2. 开始 / 重试未成功账号', command=self.start)
        self.start_button.pack(side='left', padx=4)
        ttk.Button(bar, text='停止', command=self.cancel).pack(side='left', padx=4)
        ttk.Button(bar, text='验证完成，继续', command=self.resume.set).pack(side='left', padx=4)
        ttk.Button(bar, text='3. 导出 XLSX', command=self.save).pack(side='left', padx=4)
        self.status = tk.StringVar(value='支持主页链接、视频链接、Handle 列；仅查询公开主页。')
        ttk.Label(root, textvariable=self.status, padding=12, wraplength=1000).pack(fill='x')
        self.progress = ttk.Progressbar(root)
        self.progress.pack(fill='x', padx=16, pady=8)
        frame = ttk.Frame(root)
        frame.pack(fill='both', expand=True, padx=16, pady=8)
        self.table = ttk.Treeview(frame, columns=('handle', 'name', 'followers', 'state'), show='headings')
        for key, title, width in [('handle','账号 ID（@用户名）',210), ('name','达人名称',260), ('followers','粉丝数',130), ('state','查询状态',360)]:
            self.table.heading(key, text=title)
            self.table.column(key, width=width)
        scroll = ttk.Scrollbar(frame, orient='vertical', command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        self.table.pack(fill='both', expand=True)
        ttk.Label(root, text='页面缩写粉丝数会标注为估算；未读取到的数据保持为空。自动恢复文件保存在本机应用数据目录。', padding=12).pack(fill='x')
        root.protocol('WM_DELETE_WINDOW', self.close)
        root.after(150, self.poll)

    def load(self):
        if self.running:
            return
        path = filedialog.askopenfilename(filetypes=[('Excel 工作簿', '*.xlsx')])
        if not path:
            return
        try:
            self.items = import_accounts(path)
            self.table.delete(*self.table.get_children())
            for i, item in enumerate(self.items):
                self.table.insert('', 'end', iid=str(i), values=(item['账号ID'], '', '', '待查询'))
            self.status.set(f'已导入 {len(self.items)} 个不重复账号。原表保持不变，导出结果包含来源工作表和行号。')
        except Exception as exc:
            messagebox.showerror('导入失败', str(exc))

    def start(self):
        if self.running or not self.items:
            return
        self.running = True
        self.stop.clear()
        self.import_button.state(['disabled'])
        self.start_button.state(['disabled'])
        threading.Thread(target=self.worker, daemon=True).start()

    def cancel(self):
        self.stop.set()
        self.resume.set()

    def worker(self):
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                context = p.chromium.launch_persistent_context(str(self.folder / 'browser'), channel='msedge', headless=False, viewport={'width':1280, 'height':850})
                try:
                    page = context.pages[0] if context.pages else context.new_page()
                    pending = [(i, x) for i, x in enumerate(self.items) if x['查询状态'] != '成功']
                    for done, (i, item) in enumerate(pending, 1):
                        if self.stop.is_set():
                            break
                        try:
                            self.events.put(('status', f'正在查询 @{item["账号ID"]}（{done}/{len(pending)}）'))
                            page.goto(item['主页链接'], wait_until='domcontentloaded', timeout=45000)
                            page.wait_for_timeout(2500)
                            found = extract_profile(page, item['账号ID'])
                            if not found:
                                self.resume.clear()
                                self.events.put(('status', f'@{item["账号ID"]} 未读取到数据。请查看浏览器，处理验证或加载问题后点击“验证完成，继续”；点击停止可结束。'))
                                while not self.resume.wait(.3):
                                    if self.stop.is_set():
                                        break
                                if self.stop.is_set():
                                    break
                                found = extract_profile(page, item['账号ID'])
                            if found:
                                item['达人名称'], item['粉丝数'], item['粉丝数精度'] = found
                                item['查询状态'] = '成功'
                            else:
                                item['查询状态'] = '未读取到公开数据，待重试'
                        except Exception as exc:
                            item['查询状态'] = '查询失败: ' + str(exc).splitlines()[0][:150]
                        item['查询时间UTC'] = timestamp()
                        self.events.put(('row', i, dict(item), done, len(pending)))
                        try:
                            temp = self.folder / 'autosave.tmp.xlsx'
                            export_results(self.items, temp)
                            temp.replace(self.folder / 'autosave.xlsx')
                        except Exception as exc:
                            self.events.put(('error', '自动保存失败: ' + str(exc)))
                        if self.stop.wait(4):
                            break
                finally:
                    context.close()
        except Exception as exc:
            self.events.put(('error', '浏览器启动或查询失败。请确认已安装 Microsoft Edge。\n' + str(exc)))
        finally:
            self.events.put(('end',))

    def poll(self):
        try:
            while True:
                event = self.events.get_nowait()
                if event[0] == 'status':
                    self.status.set(event[1])
                elif event[0] == 'row':
                    _, i, item, done, total = event
                    self.table.item(str(i), values=(item['账号ID'], item['达人名称'], item['粉丝数'] if item['粉丝数'] is not None else '', item['查询状态']))
                    self.progress['value'] = done / total * 100
                elif event[0] == 'error':
                    messagebox.showerror('提示', event[1])
                elif event[0] == 'end':
                    self.running = False
                    self.import_button.state(['!disabled'])
                    self.start_button.state(['!disabled'])
                    success = sum(x['查询状态'] == '成功' for x in self.items)
                    self.status.set(f'本次查询结束，成功 {success}/{len(self.items)}。可以导出或重试未成功账号。')
        except queue.Empty:
            pass
        self.root.after(150, self.poll)

    def save(self):
        if not self.items:
            return
        if self.running:
            messagebox.showinfo('提示', '请先停止查询，等本次查询结束后导出。')
            return
        path = filedialog.asksaveasfilename(defaultextension='.xlsx', initialfile='TikTok达人查询结果.xlsx', filetypes=[('Excel 工作簿','*.xlsx')])
        if path:
            try:
                export_results(self.items, path)
                messagebox.showinfo('已导出', path)
            except Exception as exc:
                messagebox.showerror('导出失败', str(exc))

    def close(self):
        if self.running:
            self.cancel()
            self.status.set('正在停止，请等查询结束后再关闭。')
        else:
            self.root.destroy()

if __name__ == '__main__':
    root = tk.Tk()
    if '--smoke-test' in sys.argv:
        from playwright.sync_api import sync_playwright
        root.withdraw()
        root.update()
        with sync_playwright() as p:
            assert p.chromium is not None
        root.destroy()
    else:
        App(root)
        root.mainloop()
